import java.net.*;
import java.io.*;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    private static final Scanner input = new Scanner(System.in);
    private static User localUser;
    static volatile boolean finished = false;

    public static void main(String[] args) {

        System.out.println("Please insert the name of the local User:");
        String localName = input.nextLine();
        localUser = new User(localName);

        try{
            int menuChoice;
            do {
                finished=false;
                menuChoice = menu();
                switch (menuChoice) {
                    case 1 -> create();
                    case 3 -> join();
                    case 0 -> System.out.println("Exiting...");
                }
            }while(menuChoice > 0);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static int menu() {
        System.out.println("""
                1. Create Room
                3. Join Room
                0. exit""");
        try{
            int response = Integer.parseInt(input.nextLine());
            return response >= 0 ? response : 5;
        }catch(NumberFormatException e){
            return 5;
        }
    }

    private static void create() {
        System.out.println("create");

        System.out.println("Insert the name of the room: ");
        String room_name = input.nextLine();

        InetAddress group = null;
        try {
            group = InetAddress.getByName("239.0.0.0");
        } catch (UnknownHostException e) {
            System.out.println("erroreeeeee");
        }
        int port = 1234;



        System.out.println("Insert the number of partecipants: ");
        int num_partecipants = Integer.parseInt(input.nextLine());

        List<String> partecipants = new ArrayList<>();
        for(int i = 0; i < num_partecipants; i++){
            String partecipant = input.nextLine();
            User u = new User(partecipant);
            partecipants.add(u.getUsername());
        }

        Room r = new Room(room_name, group, port, localUser.getUsername(), partecipants);

        System.out.println("\n");

        messaging(r, localUser);

    }

    private static void join() throws UnknownHostException {
        Room room= null;
        messaging(room, null);
    }

    private static void messaging(Room room, User user){

        try {
            MulticastSocket socket = new MulticastSocket(1234);
            socket.setTimeToLive(1);

            socket.joinGroup(InetAddress.getByName("239.0.0.0"));
            int index = 0;
            int flag = 0;
            if (room != null) {
                String inizialize = room.getUsers();
                localUser.setId(0);
                byte[] buffer = inizialize.getBytes();
                DatagramPacket datagram = new
                        DatagramPacket(buffer, buffer.length, room.getAddress(), room.getPort());
                socket.send(datagram);
                flag = 1;
            } else {
                byte[] buffer = new byte[1000];
                DatagramPacket datagram = new DatagramPacket(buffer, buffer.length, InetAddress.getByName("239.0.0.0"), 1234);
                socket.receive(datagram);
                String inizialize = new String(buffer, 0, datagram.getLength(), "UTF-8");
                String owner = get_owner(inizialize);
                String room_name = get_name(inizialize);
                List<String> partecipants = get_partecipants(inizialize);
                index = present(partecipants);
                if (index != 0) {
                    localUser.setId(index);
                    room = new Room(room_name, InetAddress.getByName("239.0.0.0"), 1234, owner, partecipants);
                    flag = 1;
                }
            }

            System.out.println("index: " + localUser.getId());
            if (flag == 1) {
                //set vector clock to 0
                int[] vector_clock = new int[room.num_users()];
                System.out.println("vector clock: ");
                for(int i=0; i< room.num_users(); i++) {
                    vector_clock[i] = 0;
                    System.out.println(vector_clock[i]);
                }

                List<Message> messages = new ArrayList<>();
                // Spawn a thread for reading messages
                Thread t = new Thread(new ReadThread(socket, room.get_name(), room.getAddress(), room.getPort(), localUser, vector_clock, room.num_users(), localUser.getId(), messages));
                t.start();

                // sent to the current group
                System.out.println("Start typing messages...\n");
                while (true) {
                    String message;
                    message = input.nextLine();
                    if(finished){
                        System.out.println("thread closed and room deleted");
                        socket.leaveGroup(room.getAddress());
                        socket.close();
                        break;
                    }
                    if (message.equalsIgnoreCase("exit")) {
                        finished = true;
                        socket.leaveGroup(room.getAddress());
                        socket.close();
                        break;
                    }
                    if (message.equalsIgnoreCase("print")) {
                        Collections.sort(messages, new Message.MessageComparator());
                        for(int i=0; i<messages.size(); i++)
                            messages.get(i).print();
                    }
                    else if(message.equalsIgnoreCase("delete")){
                        finished = true;
                        byte[] buffer = message.getBytes();
                        DatagramPacket datagram = new
                                DatagramPacket(buffer, buffer.length, room.getAddress(), room.getPort());
                        socket.send(datagram);
                        socket.leaveGroup(room.getAddress());
                        socket.close();
                        break;
                    }
                    else{
                        message = prepare_message(user, message, vector_clock, room);
                        byte[] buffer = message.getBytes();
                        DatagramPacket datagram = new
                                DatagramPacket(buffer, buffer.length, room.getAddress(), room.getPort());
                        socket.send(datagram);
                    }
                }
            }
            } catch(IOException e){
                throw new RuntimeException(e);
            }
    }

    private static int[] set_vc(int num_client){
        int[] vector_clock = new int[100];
        for(int i=0; i<num_client; i++){
            vector_clock[i] = 0;
        }
        return vector_clock;
    }

    public static int[] send_vc(User local, int[] local_vc){
        int i = localUser.getId();
        local_vc[i]= local_vc[i] + 1;

        return local_vc;
    }

    public static String prepare_message(User local, String message, int[] local_vc, Room r){
        local_vc = send_vc(local, local_vc);
        StringBuilder vector_clock = new StringBuilder(String.valueOf(local_vc[0]));
        for(int i =1; i< r.num_users(); i++){
            vector_clock.append(":").append(String.valueOf(local_vc[i]));
        }
        message = r.get_name() + "..!" +vector_clock + "::" + localUser.getUsername() + ":" + message;
        return message;
    }

    public static String get_owner(String initialize){
        String[] parsing = initialize.split(", ");
        return parsing[0];
    }

    public static String get_name(String initialize){
        String[] parsing = initialize.split(", ");
        return parsing[1];
    }

    public static List<String> get_partecipants(String initialize){
        String[] parsing = initialize.split(", ");
        List<String> partecipants = new ArrayList<String>();

        for(int i=2; i < parsing.length; i++){
            partecipants.add(parsing[i]);
        }
        return partecipants;
    }

    public static int present(List<String> list){
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
            if (list.get(i).equals(localUser.getUsername())) {
                return i+1;
            }
        }
        return 0;
    }
}