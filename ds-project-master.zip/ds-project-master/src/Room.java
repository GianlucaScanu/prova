import java.net.InetAddress;
import java.util.List;

public class Room {

    private String roomName;
    private String localUser;
    private List<String> partecipants;
    //private List<String> messages;

    private InetAddress adress;
    private int port;

    public Room(String roomName, InetAddress address, int port, String localUser, List<String> participants) {
        this.roomName = roomName;
        this.localUser = localUser;
        this.adress = address;
        this.port = port;
        this.partecipants=participants;
    }

    public Room(InetAddress address, int port, String localUser){
        this.adress = address;
        this.port = port;
        this.localUser = localUser;
    }

    public int getPort() {
        return port;
    }
    public InetAddress getAddress() {
        return adress;
    }

    public int num_users() {
        return (partecipants.size() + 1);
    }

    public String  getUsers() {
        String inizialize = localUser + ", " + roomName + ", ";
        for(int i=0; i < partecipants.size() - 1; i++){
            inizialize = inizialize + partecipants.get(i) + ", ";
        }
        inizialize = inizialize + (partecipants.get(partecipants.size() - 1));
        System.out.println(inizialize);
        return inizialize;
    }

    public String get_name(){
        return roomName;
    }
}
