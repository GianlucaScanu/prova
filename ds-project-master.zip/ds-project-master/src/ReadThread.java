import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.List;

class ReadThread implements Runnable
{
    private MulticastSocket socket;
    private InetAddress group;
    private String room_name;
    private int port;
    private User user;

    private List<Message> messages = new ArrayList<>();

    private int num_users;
    private int index;

    private int[] vector_clock;
    private static final int MAX_LEN = 1000;
    ReadThread(MulticastSocket socket,String room_name, InetAddress group,int port, User user, int[] vector_clock, int num_users, int index, List<Message> messages)
    {
        this.socket = socket;
        this.room_name=room_name;
        this.group = group;
        this.port = port;
        this.user = user;
        this.num_users = num_users;
        this.vector_clock = vector_clock;
        this.index=index;
        this.messages = messages;
    }

    @Override
    public void run()
    {

        while(!Main.finished) {
            byte[] buffer = new byte[1000];
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length, group, port);
            String message;
            try {
                socket.receive(datagram);
                message = new String(buffer, 0, datagram.getLength(), "UTF-8");

                if (message.equals("delete")) {
                    System.out.println("ROOM DELETED!!!!");
                    Main.finished = true;
                    //Thread.currentThread().interrupt();
                }

                String[] room = message.split("..!");
                if (room[0].equals(room_name)) {
                    receive_message(user, room[1], vector_clock, num_users);
                }
            } catch (IOException e) {
                System.out.println("Socket closed!");
            }
        }
        System.out.println("thread finished");
    }

    public void receive_message(User local, String message, int[] local_vc, int num_clients) {
        String[] message_vc = message.split("::");
        String[] vc = message_vc[0].split(":");
        String[] user = message_vc[1].split(":");

        if(!user[0].equals(this.user.getUsername())) {
            int[] vector_clock = new int[num_clients];
            for (int i = 0; i < num_clients; i++) {
                vector_clock[i] = Integer.parseInt(vc[i]);
                System.out.println(vector_clock[i] + " ");
            }

            local_vc = receive_vc(local, num_clients, local_vc, vector_clock, index);

            /*StringBuilder s = new StringBuilder();
            for (int i = 0; i < num_users; i++)
                s.append(local_vc[i]).append(":");*/
            System.out.println(message_vc[1] + "\t" + local_vc);
        }
        Message m = new Message(vector_clock[index], message_vc[1]);
        messages.add(m);

        //add messages in order
        //add_message(message_vc, index, num clients, );
    }

    public static int[] receive_vc(User local, int num_client, int[] local_vc, int[] remote_vc, int index){
        for(int i=0; i<num_client; i++){
            if(local_vc[i] < remote_vc[i]){
                local_vc[i]=remote_vc[i];
            }
        }
        local_vc[index] = local_vc[index] + 1;
        return local_vc;
    }
}
