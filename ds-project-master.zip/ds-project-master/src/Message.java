import java.io.Serializable;

public class Message implements Serializable {
    private int vector_clock;
    private String content;

    public Message(int vector_clock, String content) {
        this.vector_clock = vector_clock;
        this.content = content;
    }

    public void print(){
        System.out.println(content);
    }

    public int get_vc() {
        return vector_clock;
    }

    public static class MessageComparator implements java.util.Comparator<Message> {
        @Override
        public int compare(Message a, Message b) {
            return a.get_vc() - b.get_vc();
        }
    }
}